<?php
// index.php

// Capturar la URL
$url = isset($_GET['url']) ? rtrim($_GET['url'], '/') : '/';

// Definir rutas
$routes = [
    // HOME
    '/' => 'App/dashboard.php',
    'dashboard' => 'App/dashboard.php',


    // LOGIN
    'login' => 'App/login/login.php',
    'logout' => 'App/login/logout.php',
    'procesar_login' => 'App/login/procesar_login.php'
];

// Manejar la solicitud
if (array_key_exists($url, $routes)) {
    include $routes[$url];
} else {
    include '404.php'; // Archivo de error 404
}
