<?php
include_once __DIR__ . '/config/verificar_sesion.php';
verificar_sesion();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            margin-top: 50px;
        }
        .logout-btn {
            margin-top: 20px;
            padding: 10px 20px;
            background-color: #f44336;
            color: white;
            border: none;
            cursor: pointer;
        }
        .logout-btn:hover {
            background-color: #d32f2f;
        }
    </style>
</head>
<body>
    <h1>Bienvenido a la Página Dashboard</h1>
    <p>Esta es la página de dashboard de tu aplicación.</p>

    <form action="logout" method="post">
        <button type="submit" class="logout-btn">Cerrar Sesión</button>
    </form>
</body>
</html>
