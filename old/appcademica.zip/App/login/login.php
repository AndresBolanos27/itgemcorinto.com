<?php
session_start();

// Inicializar variables de error
$error_correo = isset($_SESSION['error_correo']) ? $_SESSION['error_correo'] : '';
$error_contrasena = isset($_SESSION['error_contrasena']) ? $_SESSION['error_contrasena'] : '';

// Limpiar los mensajes de error después de mostrarlos
unset($_SESSION['error_correo']);
unset($_SESSION['error_contrasena']);

// Obtener el mensaje de error de los parámetros GET
$mensaje = isset($_GET['mensaje']) ? $_GET['mensaje'] : '';
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión</title>
    <script>
        // Mostrar el mensaje de error si existe
        window.onload = function() {
            var mensaje = "<?php echo $mensaje; ?>";
            if (mensaje) {
                alert(mensaje);
            }
        };
    </script>
</head>
<body>
    <h1>Iniciar Sesión</h1>
    <form action="procesar_login" method="post">
        <label for="correo">Correo:</label><br>
        <input autocomplete="off" type="email" id="correo" name="correo" required><br>
        <?php if (!empty($error_correo)) echo "<p style='color:red;'>$error_correo</p>"; ?><br>

        <label for="contrasena">Contraseña:</label><br>
        <input autocomplete="off" type="password" id="contrasena" name="contrasena" required><br>
        <?php if (!empty($error_contrasena)) echo "<p style='color:red;'>$error_contrasena</p>"; ?><br>

        <input type="submit" value="Iniciar Sesión">
    </form>
</body>
</html>
