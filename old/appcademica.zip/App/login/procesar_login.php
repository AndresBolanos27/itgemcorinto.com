<?php
// procesar_login.php
session_start();

include_once __DIR__ . '/../config/database.php';

// Obtener datos del formulario
$correo = $_POST['correo'];
$contrasena = $_POST['contrasena'];

// Evitar inyecciones SQL
$correo = $conn->real_escape_string($correo);
$contrasena = $conn->real_escape_string($contrasena);

// Consulta para verificar el usuario
$sql = "SELECT * FROM usuarios WHERE correo = '$correo'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    // Verificar la contraseña (asumiendo que las contraseñas están hasheadas)
    if (password_verify($contrasena, $row['contrasena'])) {
        // Inicio de sesión exitoso
        $_SESSION['usuario_id'] = $row['id'];
        $_SESSION['usuario_nombre'] = $row['nombre'];
        $_SESSION['usuario_rol'] = $row['rol'];
        header("Location: dashboard");
        exit();
    } else {
        // Contraseña incorrecta
        $_SESSION['error_contrasena'] = "Contraseña incorrecta.";
        header("Location: login");
        exit();
    }
} else {
    // Usuario no encontrado
    $_SESSION['error_correo'] = "Correo no encontrado.";
    header("Location: login");
    exit();
}

$conn->close();
